import React from 'react';
import { Navbar, Nav, Container, FormControl, Button, InputGroup } from 'react-bootstrap';

const NavBarcomponent = ()=>{
  return (
  <h1>Hello</h1>
  );
};

export default NavBarcomponent;
