export const API_URL = "http://localhost:5000/";

export const JOB_SEEKER = "Job Seeker";
export const JOB_RECURITER = "Job Recruiter";