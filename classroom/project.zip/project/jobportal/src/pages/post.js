import React from "react";
import PostJob from "../components/postjob";
export default function Post()
{
    return(<PostJob />);
}