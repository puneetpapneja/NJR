import React from "react";

import Jobs from "../components/Jobs";
export default function Jobpage()
{
    return(<Jobs/>);
}