import React from "react";
import PostedJob from "../components/Postedjob";

export default function Posted() {
    return (
        <PostedJob/>
    )
}