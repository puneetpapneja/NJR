import React from "react";

import AppliedJob from "../components/appliedjob";
export default function Apply()
{
    return(<AppliedJob />);
}