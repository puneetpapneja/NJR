import React from "react";
import Developers from "../components/Developers";

export default function DeveloperPage() {
    return (
        <Developers />
    )
}