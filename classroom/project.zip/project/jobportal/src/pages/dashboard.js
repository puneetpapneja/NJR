import React from "react";
// import "./dashboard.css";

import Content from "../components/content";

export default function Dashboard() {
  return (
    <>
     
      <Content />
    
    </>
  );
}