import React from "react";
// import Button from "react-bootstrap/Button";
// import Container from "react-bootstrap/Container";
// import Form from "react-bootstrap/Form";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
import "@fortawesome/fontawesome-free/css/all.min.css";
function Footer(){
    return <>
         <footer className="footer py-3 bg-black py-2 text-white text-center fixed-bottom">
        <p>
          &copy;TM@2023 - Techno India NJR Institute of Technology-All Rights
          Reserved
        </p>
      </footer>
    </>
}
export default Footer;