const PORT = 5000;
module.exports = {
  port: PORT,
};
